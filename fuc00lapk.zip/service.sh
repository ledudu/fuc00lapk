#!/system/bin/sh
MODDIR=${0%/*}
rm -rf /data/data/com.coolapk.market/cache/GDTDOWNLOAD
mkdir /data/data/com.coolapk.market/cache/GDTDOWNLOAD
chmod -R 0000 /data/data/com.coolapk.market/cache/GDTDOWNLOAD/